

function About(){
    return(
      <div className="pt-10  bg-[url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNLnD4edOstpBHZHcqtDIdE2bonxKgbQzueQ&s')] ... bg-cover bg-no-repeat bg-center">
        <h1 style={{fontFamily:"sans-serif",textAlign:"center",fontSize:"30px",color:"white"}}>About Us</h1>
<div style={{display:"flex",justifyContent:"space-between",paddingTop:"35px"}}>
  <div>
  <p style={{color:"white",paddingLeft:"30px",fontFamily:"sans-serif" ,fontSize:"20px"}}>Fresh Smart Fitness incorporation of technology and data into theike<br/> wearable devices tracking progress, AI-powered workout recommendations,<br/> and smart fitness equipment with interactive features. Gyms are increasingly<br/> leveraging data to understand their clients' needs, track progress, 
 and offer<br/> personalized recommendations. </p>
 <button style={{padding:"10px",borderRadius:"5px",color:"white",border:"1px solid gold",marginLeft:"30px",marginTop:"10px"}} className="hover:bg-amber-400">Subscribe</button>
 </div>
  <div>
  <img style={{marginBottom:"10px",borderRadius:"20px",marginRight:"20px"}} src="https://img.freepik.com/free-photo/low-angle-view-unrecognizable-muscular-build-man-preparing-lifting-barbell-health-club_637285-2497.jpg?semt=ais_hybrid&w=740" width="350px" height="300px"/>
    </div>
    </div>
    <div style={{display:"flex",justifyContent:"center",paddingTop:"20px",paddingBottom:"10px"}}>
      <img style={{paddingLeft:"8px",borderRadius:"10px"}} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqEyFHvuFMAc-knprFmaQcUBLgB4bTxJwL9Q&s"height="200px" width="300px"/>
   <img style={{paddingLeft:"8px",borderRadius:"10px"}} src="https://t4.ftcdn.net/jpg/04/07/45/29/240_F_407452902_HxULtJOZKvpLa0VSyW5ffFdOr2mXXb8f.jpg"height="200px" width="300px"/>
   <img style={{paddingLeft:"8px",borderRadius:"10px"}} src="https://t4.ftcdn.net/jpg/06/52/75/09/240_F_652750986_5dOsja3QlDqJC0g3kM8rgHuVGXGAYdpp.jpg" height="200px" width="300px"/>
    </div> 
        </div>
    )
}
export default About;