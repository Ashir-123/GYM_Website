function Footer(){
  
    return(
        <footer style={{textAlign:"center",padding:"20px",backgroundColor:"black",paddingTop:"10px",color:"white"}}>
           &copy; 2025 Fresh Start Fitness.All Rights Reserved.
        </footer>
    )
}
export default Footer;