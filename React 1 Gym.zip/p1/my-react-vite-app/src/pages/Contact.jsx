
function Contact(){
    return(
        <>
        <div className="pt-5  bg-[url('C:\Users\dell\Desktop\p1\my-react-vite-app\src\assets\images.jpg')] ... bg-cover bg-no-repeat bg-center">
            <h1 style={{fontFamily:"sans-serif",textAlign:"center",fontSize:"35px",color:"white",paddingTop:"95px"}}>Contact Us</h1>
            
        <form style={{display:"flex",flexDirection:"column",alignItems:"center",paddingTop:"20px"}}>
           
         <input style={{height:"40px",width:"300px",border:"1px solid white",fontFamily:"sans-serif",color:"white",borderRadius:"5px",marginTop:"20px",textAlign:"center"}}  type="text" placeholder="Enter Your First Name"/>
            <input style={{height:"40px",width:"300px",border:"1px solid white",fontFamily:"sans-serif",color:"white",borderRadius:"5px",marginTop:"20px",textAlign:"center"}} type="text" placeholder="Enter Your Last Name"/>
            <input style={{height:"40px",width:"300px",border:"1px solid white",fontFamily:"sans-serif",color:"white",borderRadius:"5px",marginTop:"20px",textAlign:"center"}}  type="email" placeholder="Enter  @gmail.com"/>
            <input style={{height:"40px",width:"300px",border:"1px solid white",fontFamily:"sans-serif",color:"white",borderRadius:"5px",marginTop:"20px",textAlign:"center"}} type="password" placeholder="Enter Password"/>
            <input style={{height:"40px",width:"300px",border:"1px solid white",fontFamily:"sans-serif",color:"white",borderRadius:"5px",marginTop:"20px",textAlign:"center"}} type="text" placeholder="+92 345 678 90"/>
            <button style={{padding:"15px",borderRadius:"5px",color:"white",border:"1px solid lightblue",marginTop:"50px",fontFamily:"sans-serif",marginBottom:"50px"}} className="hover:bg-blue-400">Submit</button>
        </form>
        </div>
        </>
    )
}
export default Contact;