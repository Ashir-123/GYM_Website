import {useState} from 'react';

function Home(){
const [darkMode,setdarkMode]=useState(false);
    return(
        <>
<div className=" bg-[url('C:\Users\dell\Desktop\p1\my-react-vite-app\src\assets\im6.jpg')] ... bg-no-repeat bg-cover bg-center ">

<div style={{display:"flex",justifyContent:"space-between"}}>
<div >
   <h1 className="text-4xl flex pt-25 text-white pl-10  font-bold"><span style={{color:"lightblue"}}>Fresh Start</span><br/>Fitness</h1>
   <p className="text-normal flex text-white pt-7 pl-10">You’re going to have to let it hurt. Let it suck. The harder<br/> you work, the better you will look. Your appearance isn’t parallel<br/> to how heavy you lift, it’s parallel to how hard you work.</p>
<button style={{padding:"14px",borderRadius:"5px",color:"white",marginTop:"20px",marginLeft:"35px",marginBottom:"10px"}} className="border hover:bg-cyan-400">Subscribe</button>
<button  style={{padding:"14px",borderRadius:"5px",color:"white",marginTop:"20px",marginBottom:"10px",marginLeft:"4px",border:"1px solid white"}} className="border hover:bg-cyan-400">Contact Us</button>
</div>
<div style={{width:"240px",height:"290px",display:"flex",justifyContent:"center",marginTop:"50px",marginRight:"50px",border:"1px solid white",borderRadius:"20px"}} className="bg-transparent">
    <form>
<h2 style={{paddingTop:"25px",textAlign:"center",color:"white",fontFamily:"sans-serif",fontSize:"20px"}}>Login</h2><br/>
<label style={{color:"white",paddingLeft:"30px"}}>Name</label><br/>
<input style={{width:"150px",height:"30px",border:"1px solid white",marginLeft:"30px",marginTop:"10px",borderRadius:"5px",color:"white",fontSize:"13px",textAlign:"center"}} type="text" placeholder="Enter Name"/><br/>
<label style={{color:"white",paddingLeft:"30px",marginTop:"10px"}}>Password</label>
<input style={{width:"150px",height:"30px",border:"1px solid white",marginLeft:"30px",marginTop:"10px",borderRadius:"5px",color:"white",fontSize:"13px",textAlign:"center"}} type="password" placeholder="Enter Password"/>
<button style={{width:"150px",height:"30px",border:"1px solid white",marginLeft:"30px",marginTop:"20px",borderRadius:"5px",color:"white"}} className="bg-cyan-400"> Submit</button>
<p style={{color:"white",paddingLeft:"30px",fontSize:"13px",marginTop:"10px"}}>Don't have an account? <span className="text-cyan-400">Sign Up</span></p>
        </form>
</div>

</div>


</div>
<div style={{paddingTop:"28px"}}>
<h1 style={{textAlign:"center",fontFamily:"sans-serif",fontSize:"28px",paddingTop:"10px"}}><span style={{color:"grey"}}>Build The Body</span> Of Your Dreams</h1>
<p style={{textAlign:"center",fontFamily:"sans-serif",paddingTop:"20px",fontSize:"17px"}}>Just believe in yourself. Even if you don’t, just pretend that you do and at some point, you will.</p>
<div style={{display:"flex",justifyContent:"center",alignItems:"center",paddingTop:"30px"}}>
    <img  style={{paddingLeft:"8px",borderRadius:"15px",marginBottom:"10px"}}src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSduEm7TQ9qY-lXUl5OOhX3Ai951p0CAYVyCw&s" height="200px" width="240px"/>
    <img style={{paddingLeft:"8px",borderRadius:"17px",marginBottom:"10px"}}src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTk_7SrL5Prc0Eor2OuGyXgOMEv6KYJ-GoLSnXifmXdi8waT7xn1JHr5Z1wsRFqMeNeraE&usqp=CAU" height="200px" width="240px"/>
    <img style={{paddingLeft:"8px",borderRadius:"15px",marginBottom:"10px"}}src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfjhmf-cLuG3YXj8n4u8tPz7vArxH7KkbV518J4tH-OCt2zrH5J4gwnXl0oniTNUNndCs&usqp=CAU" height="200px" width="245px"/>
</div>
</div>

</>
    )
}
export default Home;