function Services(){
    return(
      <div className="pt-10  bg-[url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTW1MBhb349xuIrT4TZ-hccIvnUGBA-wFAyPQ&s')] ... bg-cover bg-no-repeat bg-center">
        <h1 style={{fontFamily:"sans-serif",textAlign:"center",fontSize:"30px",color:"white",paddingTop:"20px"}}>Services</h1>
        <div style={{display:"flex",justifyContent:"space-between",paddingTop:"30px"}}>
          <div>

         
        <p style={{color:"white",paddingLeft:"30px",fontFamily:"sans-serif" ,fontSize:"20px"}}>Fresh Start Fitness offers personalized fitness services, often with a focus <br/> on rehabilitation or individuals new to exercise.They provide tailored fitness<br/>  plans, personal training, and sometimes include nutrition  planning to help <br/> clients achieve their goals. This can include specialized areas like senior <br/> fitness, oncology recovery, and adaptive training.  </p>
       
        <button style={{padding:"10px",borderRadius:"5px",color:"white",border:"1px solid lightblue",marginLeft:"30px",marginTop:"20px"}} className="hover:bg-cyan-700">Book Now</button>
        </div>
        <div>
          <img style={{marginBottom:"15px",borderRadius:"20px",marginRight:"20px"}}  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNfxHm5hMB2xwEwkdYAEGo_6glIrXA-O9SWy7kfpdrx9PhsSBaecN1s8e5YeU4xG6nXj8&usqp=CAU" width="350px" height="300px"/>
        </div>
      </div>
      <div  style={{display:"flex",justifyContent:"center",paddingTop:"35px",paddingBottom:"10px"}}>
        <img style={{paddingLeft:"8px",borderRadius:"10px"}}src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHnBzABMqjYrMg3naD-ipSFIS6pUeEfc85xQ&s" height="200px" width="300px"/>
        <img style={{paddingLeft:"8px",borderRadius:"10px"}}src="https://t4.ftcdn.net/jpg/02/12/08/31/360_F_212083194_1HCzQsAVdrqtkhTlTSKKubDUAROfWUON.jpg" height="200px" width="300px"/>
        <img style={{paddingLeft:"8px",borderRadius:"10px"}}src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBwVPLi1VSWPtgap-1iJ_8YJ8VPmnE0bTlzQ&s" height="200px" width="300px"/>

      </div>
      </div>
    )
}
export default Services;