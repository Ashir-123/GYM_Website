function NavBar(){
    return(
        <div style={{padding:"10px"}} className="bg-black">

<div style={{display:"flex",justifyContent:"space-between", alignItems:"center"}}>
<h1 className="font-bold  font-sans  text-white p-2 flex text-xl ">
<img style={{borderRadius:"20px",marginRight:"7px"}} src="https://is5-ssl.mzstatic.com/image/thumb/Purple114/v4/76/da/05/76da0569-6b11-a7aa-9798-002950ac3cff/source/256x256bb.jpg" width="30px" height="30px"/>
<span style={{color:"lightblue",paddingRight:"4px"}}>Fresh Start</span > Fitness.</h1>
    <nav style={{ padding:"2px",listStyleType:"none",display:"flex"}}>
        <li className="text-sm font-sans text-white border p-3 rounded ml-3 hover:bg-cyan-400  "><a href="/">Home</a></li>
        <li className="text-sm font-sans  text-white border p-3 rounded ml-3  hover:bg-cyan-400 "><a href="/about">About</a></li>
        <li className="text-sm font-sans  text-white border p-3 rounded ml-3  hover:bg-cyan-400 "><a href="/services">Services</a></li>
        <li className="text-sm font-sans   text-white border p-3 rounded ml-3 hover:bg-cyan-400 "><a href="/contact">Contact Us</a></li>
<button className="text-sm font-sans text-white border p-3 rounded ml-50 hover:bg-cyan-400 ">Sign Up</button>
<button className="text-sm font-sans text-white border p-3 rounded ml-2 hover:bg-cyan-400 ">Login</button>
       
    </nav>
    </div>

</div>
    )
}
export default NavBar;